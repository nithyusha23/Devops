def call(String branch){
	
	checkout([
			$class: 'GitSCM', 
			branches: [[name: branch]],		
			userRemoteConfigs: [[
			credentialsId:'b075b292-3f9f-4cf7-857b-5c186a1d5cbd', 
			url: 'ssh://git@radcab:2222/mionline-web/radian-applications.git]'
			]],
			extensions: [[
			$class: 'LocalBranch', 
			localBranch: "**"
			]]
		])
		echo "Hello"
}