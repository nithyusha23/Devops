class Checkoutcode implements Serializable{
	private final script
	
	Checkoutcode(script) 
	{
    this.script = script
	}
	def checkoutcode(def branch,checkoutCredentials,projectUrl) 
	{
		try
		{
			    script.checkout([
				$class: 'GitSCM', 
				branches: [[name: branch]],		
				userRemoteConfigs: [[
				credentialsId:checkoutCredentials, 
				url: projectUrl
				]],
				extensions: [[
				$class: 'LocalBranch', 
				localBranch: "**"
				]]
			])
		}
		catch(Exception e)
		{
			script.echo "-------Failed in Checkout Stage--------------"
			script.error e.message
		}
		finally
		{
			
		}
	}
}