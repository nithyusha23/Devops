param(
    [Parameter(Mandatory=$true)]
    [string]$PassKey,
    
    [Parameter(Mandatory=$true)]
    [string]$ValuetoEncrypt
 
)
$key = [System.Convert]::FromBase64String("$PassKey")
#Write-Host "Enter key to encrypt and then press enter" 
$ValuetoEncrypt | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString -Key $key  