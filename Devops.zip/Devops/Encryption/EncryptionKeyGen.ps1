Set-ExecutionPolicy -ExecutionPolicy RemoteSigned
[System.Security.Cryptography.RandomNumberGenerator]$gen = `
    New-Object System.Security.Cryptography.RNGCryptoServiceProvider
$bytes = New-Object "System.Byte[]" 32
$gen.GetBytes($bytes)
[System.Convert]::ToBase64String($bytes)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned