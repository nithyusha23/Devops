def deployCode(def workspace,def credentials,def deploysource)
{
	try
	{
		withCredentials([string(credentialsId: "${credentials}", variable: 'ServerPassword')])
		{
			echo "------------Taking backup before deploying--------------"
			bat """
				Net use * /delete /y
				NET USE \\\\${env.servername}\\IPC"\$" /USER:${env.serverusername} ${ServerPassword}
				mkdir \\\\${env.servername}\\D"\$"\\${env.previous2backup}
				robocopy \\\\${env.servername}\\D"\$"\\${env.previous1backup} \\\\${env.servername}\\D"\$"\\${env.previous2backup} /s
				rd /s /q \\\\${env.servername}\\D"\$"\\${env.previous1backup}
				robocopy \\\\${env.servername}\\D"\$"\\${env.latestbackup} \\\\${env.servername}\\D"\$"\\${env.previous1backup} /s
				rd /s /q \\\\${env.servername}\\D"\$"\\${env.latestbackup}
				robocopy \\\\${env.servername}\\D"\$"\\${env.deploymentlocation} \\\\${env.servername}\\D"\$"\\${env.latestbackup} /s
				Net use * /delete /y
			"""
			echo "-------------------Deploying the code---------------"
			try
			{
				
				bat """
					NET USE \\\\${env.servername}\\IPC"\$" /USER:${env.serverusername} ${ServerPassword}
					rd /s /q \\\\${env.servername}\\D"\$"\\${env.deploymentlocation}
					robocopy ${deploysource} \\\\${env.servername}\\D"\$"\\${env.deploymentlocation} /s
					Net use * /delete /y
				"""
			}
			catch(Exception e)
			{
				echo "--------Failed to deploy the code. Rolling back the changes as a part of auto recovery---------"
				bat """
					NET USE \\\\${env.servername}\\IPC"\$" /USER:${env.serverusername} ${ServerPassword}
					rd /s /q \\\\${env.servername}\\D"\$"\\${env.deploymentlocation}
					robocopy \\\\${env.servername}\\D"\$"\\${env.latestbackup} \\\\${env.servername}\\D"\$"\\${env.deploymentlocation} /s
					rd /s /q \\\\${env.servername}\\D"\$"\\${env.latestbackup}
					robocopy \\\\${env.servername}\\D"\$"\\${env.previous1backup} \\\\${env.servername}\\D"\$"\\${env.latestbackup} /s
					rd /s /q \\\\${env.servername}\\D"\$"\\${env.previous1backup}
					robocopy \\\\${env.servername}\\D"\$"\\${env.previous2backup} \\\\${env.servername}\\D"\$"\\${env.previous1backup} /s
					rmdir /s /q \\\\${env.servername}\\D"\$"\\${env.previous2backup}
					Net use * /delete /y
				"""
				error "Deployment failed and changes are rolled back"

			}
			echo "-----------Deleting the third backup and closing the connection-------------"
			bat """
				NET USE \\\\${env.servername}\\IPC"\$" /USER:${env.serverusername} ${ServerPassword}
				rmdir /s /q \\\\${env.servername}\\D"\$"\\${env.previous2backup}
				Net use * /delete /y
			"""
			
		}	
					
	}
	catch(Exception e)
	{
		
		echo "-------Failed to Deploy Code--------------"
		error e.message
	}
	finally
	{
		
	}
}
return this;