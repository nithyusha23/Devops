def transformWebConfig(def workspace,def outputpath)
{
    echo "Transorming Web.config"
	try
	{
		dir("$workspace")
		{
			withEnv(["inputpath=${env.transformationinputfilepath}",
										"outputpath=${outputpath}",
													"scriptpath=${env.transformationscriptpath}"])
			{
				powershell('''
							.\\Devops\\Transformation\\Transform.ps1 -InputFile $env:inputpath -OutputFile $env:outputpath -Script $env:scriptpath
					''')
			}	
		}	
	}
	catch(Exception e)
	{
		echo "-------Failed to transform web.config file--------------"
		error e.message
	}
	finally
	{
	
	}
}

def transformPublishXml(def workspace,def passkeydb)
{
    echo "Transforming publish.xml"
	try
	{
		withCredentials([string(credentialsId: passkeydb, variable: 'PassKey')])
		{
		  
			withEnv(["dbpasskey=${PassKey}",
								"inputpath=${env.dbtransformationinputfilepath}",
											"outputpath=${env.dbtransformationoutputfilepath}",
														"scriptpath=${env.dbtransformationscriptpath}"])
			{
				powershell('''
							.\\Devops\\Transformation\\Transform.ps1 -InputFile $env:inputpath -OutputFile $env:outputpath -Script $env:scriptpath -passkey $env:PassKey
					''')
			}	
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to transform publish.xml file--------------"
		error e.message
	}
	finally
	{
	
	}
}
def transformJson(def workspace,def jsonfilepath)
{
    echo "transforming json"
	withEnv(["Inputfile=${jsonfilepath}",
								"serviceurl=${env.transserviceurl}", "bizusername=${env.bizusername}","bizpassword=${env.bizpassword}","environment=${env.transenvironment}"])
	{
		powershell('''
							.\\Devops\\Transformation\\transformjs.ps1 -scriptpath $env:Inputfile -PolicyInquiryUrl $env:serviceurl -Username $env:bizusername -Password $env:bizpassword -Environment $env:environment
						''')
	}
}

def transformAPIWebConfig(def workspace,def output)
{
    echo "transforming api web config"
	withEnv(["inputpath=${env.apitransformationinputfilepath}",
										"outputpath=${output}",
													"scriptpath=${env.apitransformationscriptpath}"])
			{
				powershell('''
							.\\Devops\\Transformation\\Transform.ps1 -InputFile $env:inputpath -OutputFile $env:outputpath -Script $env:scriptpath
					''')
			}	
}

return this;