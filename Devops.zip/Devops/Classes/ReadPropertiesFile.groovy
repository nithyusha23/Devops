def Properties
def sonarurl
def readPropertiesFile(def filepath,def key)
{
	try
	{	
		props = new Properties()
		File globalProperties = new File(filepath)
		props.load(globalProperties.newDataInputStream())
		value = props.getProperty(key)
	}
	catch(Exception e)
	{
		echo "-------Failed to read the Properties file--------------"
		error e.message
	}
	finally
	{
	
	}
	return value
}
def callreadPropertiesMicroservice(def workspace,def path)
{
	try
	{
		propfile = load "${workspace}\\Devops\\Classes\\ReadPropertiesFile.groovy"
		env.majorversion = propfile.readPropertiesFile(path,"majorversion")
		env.minorversion = propfile.readPropertiesFile(path,"minorversion")
	    env.assemblycspath = propfile.readPropertiesFile(path,"assemblycsversionpath")
	    env.revisionidpath = propfile.readPropertiesFile(path,"revisionid")
	    env.npmpath = propfile.readPropertiesFile(path,"npmpath")
		env.npmdirectory = propfile.readPropertiesFile(path,"npmdirectory")
		env.vbassemblyversioning = propfile.readPropertiesFile(path,"vbassemblyversioning")
		env.csassemblyversioning = propfile.readPropertiesFile(path,"csassemblyversioning")
		env.assemblyfilepath = propfile.readPropertiesFile(path,"assemblyversionpath")
		env.msbuildpath = propfile.readPropertiesFile(path,"msBuildPath")
		env.builddirectory = propfile.readPropertiesFile(path,"builddirectory")
		env.publishfolder = propfile.readPropertiesFile(path,"publishfolder")
		env.csprojname = propfile.readPropertiesFile(path,"csprojname")
		env.sonarurl = propfile.readPropertiesFile(path,"sonarurl")
		env.sonarusername = propfile.readPropertiesFile(path,"sonarusername")
		env.sonarloglevel = propfile.readPropertiesFile(path,"sonarloglevel")
		env.sonarverbose = propfile.readPropertiesFile(path,"sonarverbose")
		env.sonaropencoverpath = propfile.readPropertiesFile(path,"sonaropencoverpath")
		env.sonarprojectname = propfile.readPropertiesFile(path,"sonarprojectname")
		env.sonarprojectversion = propfile.readPropertiesFile(path,"sonarprojectversion")
		env.testbuildpath = propfile.readPropertiesFile(path,"testbuildpath")
		env.testbuildoutputpath = propfile.readPropertiesFile(path,"testbuildoutputpath")
		env.deploymentdetailslocation =propfile.readPropertiesFile(path,"deploymentdetailslocation")
		env.dbdeployment = propfile.readPropertiesFile(path,"dbdeployment")
		env.transserviceurl = propfile.readPropertiesFile(path,"${env.Environment}_policyinquiryserviceurl")
		env.bizusername = propfile.readPropertiesFile(path,"${env.Environment}_bizusername")
		env.bizpassword = propfile.readPropertiesFile(path,"${env.Environment}_bizpassword")
		env.transenvironment = propfile.readPropertiesFile(path,"${env.Environment}_environment")
		env.jsonfilepath = propfile.readPropertiesFile(path,"${env.Environment}_jsonfilepath")
		env.deploymentlocation = propfile.readPropertiesFile(path,"${env.Environment}_DeploymentLocation")
		env.latestbackup = propfile.readPropertiesFile(path,"latestbackup")
		env.previous1backup = propfile.readPropertiesFile(path,"previous1backup")
		env.previous2backup = propfile.readPropertiesFile(path,"previous2backup")
		env.servername = propfile.readPropertiesFile(path,"${env.Environment}_ServerName")
		env.serverusername = propfile.readPropertiesFile(path,"${env.Environment}_UserName")
		env.artifactoryurl = propfile.readPropertiesFile(path,"artifactoryurl")
		env.jfrogrepo = propfile.readPropertiesFile(path,"${env.Environment}_JfrogRepo")
		env.emailrecipients = propfile.readPropertiesFile(path,"emailrecipients")
		
		
		env.PAS = propfile.readPropertiesFile(path,"${env.Environment}_PAS")
		env.PolicyActivation = propfile.readPropertiesFile(path,"${env.Environment}_PolicyActivation")
		env.SOLR = propfile.readPropertiesFile(path,"${env.Environment}_SOLR")
		env.SFDC = propfile.readPropertiesFile(path,"${env.Environment}_SFDC")
		env.GetOCARUrl = propfile.readPropertiesFile(path,"${env.Environment}_GetOCARUrl")
		env.VMS = propfile.readPropertiesFile(path,"${env.Environment}_VMS")
		env.GetOCAR_VMSUrl = propfile.readPropertiesFile(path,"${env.Environment}_GetOCAR_VMSUrl")
		env.transformationinputfilepath = propfile.readPropertiesFile(path,"${env.Environment}_transformationinputfilepath")
		env.transformationscriptpath = propfile.readPropertiesFile(path,"${env.Environment}_transformationscriptpath")

		
	}
	catch(Exception e)
	{
		echo "-------Failed to read the Properties file--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;