def build(def workspace)
{
	try
	{
		dir("${workspace}\\$env.builddirectory")
		{
		    publishcmd = "dotnet publish \"${env.csprojname}\" /p:Configuration=Release /p:FileVersion=\"${env.folderversion}\" -o \"${workspace}\\$env.publishfolder\""
            bat publishcmd
		}	
	}
	catch(Exception e)
	{
		echo "-------Failed to Build--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;