def build(def workspace)
{
	try
	{
		bat "nuget restore"
		dir("${workspace}\\$env.builddirectory")
		{
		    buildcmd = """ \"${env.msBuildPath}\" \"${env.csprojname}\" /p:Configuration=Release /p:OutputPath=\"${workspace}\\publish\" /p:WebPublishMethod=FileSystem """
		    bat buildcmd
		}	
	}
	catch(Exception e)
	{
		echo "-------Failed to Build--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;