def getArtifactsandUnzip(def workspace,def jfrogcredentials)
{
		JfrogRepoUrl = "${env.artifactoryurl}/${env.JOB_NAME}_${env.LowerEnvironment}/${env.ArtifactVersion}"
		echo "$JfrogRepoUrl"
		withCredentials([usernamePassword(credentialsId: "${jfrogcredentials}", passwordVariable: 'Jfrogpassword', usernameVariable: 'Jfroguser')]) 
		{
			bat """curl -u %Jfroguser%:%Jfrogpassword% -k \"${JfrogRepoUrl}\" -o \"${workspace}\\${env.ArtifactVersion}\""""
		}
		copy = load "$workspace\\Devops\\Classes\\Commonmethods.groovy"
		copy.fileunzipoperation("${workspace}\\${env.ArtifactVersion}","${workspace}")
		splitarray = "${env.ArtifactVersion}".split(".zip")
		env.unzippedartifactfolder = splitarray[0]
}
def zipanduploadartifactsJFrog(def workspace,def jfrogcredentials)
{
	try
	{
		delete = load "${workspace}\\Devops\\Classes\\Commonmethods.groovy"
		delete.filedeleteoperation("${env.ArtifactVersion}")
		copy.filezipoperation("${env.unzippedartifactfolder}")
		env.JfrogRepoUrl = "${env.artifactoryurl}/${env.JOB_NAME}_${env.Environment}/${env.unzippedartifactfolder}.zip"
		withCredentials([usernamePassword(credentialsId: "${jfrogcredentials}", passwordVariable: 'Jfrogpassword', usernameVariable: 'Jfroguser')]) 
		{
			bat """curl -v -u %Jfroguser%:%Jfrogpassword% -k -X PUT \"${env.JfrogRepoUrl}\" -T \"${workspace}\\${env.unzippedartifactfolder}.zip\""""
		}
		
	}
	catch(Exception e)
	{
		echo "-------Failed to upload artifacts to JFrog--------------"
		error e.message
	}
	finally
	{
		
	}
}
return this;