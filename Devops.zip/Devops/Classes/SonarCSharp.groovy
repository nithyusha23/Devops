def sonarAnalysisCSharp(def workspace,def passwordsonar)
{
	try
	{
	    dir("${workspace}\\${env.builddirectory}")
	    {
			withSonarQubeEnv('SonarQubeMSBuild')
			{
				withCredentials([string(credentialsId: "${passwordsonar}", variable: 'sonarpassword')]) 
				{
						bat """ dotnet \"${env.SonarMsBuild}\\SonarScanner.MSBuild.dll\" begin /k:${env.sonarprojectname} \
						/n:${env.sonarprojectname} \
						/v:${env.sonarprojectversion} \
						/d:sonar.host.url=${env.sonarurl} \
						/d:sonar.login=${env.sonarusername} \
						/d:sonar.password=${sonarpassword} \
						/d:sonar.verbose=${env.sonarverbose} \
					    /d:sonar.cs.opencover.reportsPaths="%CD%\\coverage.xml" \
					    /d:sonar.coverage.reportPath="%CD%\\coverage.xml" """
						
						bat """ dotnet new sln -n \"${env.JOB_NAME}\" """
						
						bat """ dotnet sln add \"${env.csprojname}\" . """
						
						bat """ dotnet build \"${env.JOB_NAME}.sln\" /p:Configuration=Release """
						
						/*dir("${workspace}\\${env.testbuildpath}")
						{
							bat """ dotnet build /p:configuration=release -o \"${env.testbuildoutputpath}\" """
							common = load "$workspace\\Devops\\Classes\\Commonmethods.groovy"
						}*/
						dir("${workspace}\\${env.testbuildpath}")
						{
							
						bat """ "C:\\Program Files (x86)\\opencover\\OpenCover.Console.exe" -target:"C:\\Program Files\\dotnet\\dotnet.exe" -targetargs:"test UnitTest.csproj" -filter:"+[*]* -[*.Tests]* -[xunit.*]*" -register:user -output:coverage.xml -oldStyle """
						}
						dir("${workspace}")
						{
						    common = load "$workspace\\Devops\\Classes\\Commonmethods.groovy"
    						common.filecopyoperation("${env.testbuildpath}\\coverage.xml", "${env.builddirectory}")
    						//common.filecopyoperation("${env.testbuildpath}\\${env.testbuildoutputpath}\\testresults.trx", "${env.builddirectory}")
						}
						bat """ dotnet \"${env.SonarMsBuild}\\SonarScanner.MSBuild.dll\" end /d:sonar.login=${env.sonarusername} \
							/d:sonar.password=${sonarpassword} """
				}
			}	
					sleep(30)
					timeout(time:15, unit: 'MINUTES') 
					{ 
						def qg = waitForQualityGate() 
						if ((qg.status != 'OK')) 
						{
							echo "----------------C# Quality Gate Failure-------------------------"
							error "Pipeline aborted due to following quality gate failure: StaticScan=${qg.status}"
						}              
											
					}
					
	    }//dir end
	}//try end
	catch(Exception e)
	{
		echo "-------Failed to perform sonar analysis on C# Code--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;