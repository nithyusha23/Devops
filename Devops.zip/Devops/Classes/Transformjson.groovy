import java.util.*
import groovy.json.*
def transformjsonfile(def globalpropertiespath,def jsonfilepath)
{
    Properties props = new Properties();
    props.load(new FileInputStream(globalpropertiespath));
    for (Enumeration<?> e = props.propertyNames(); e.hasMoreElements(); ) 
    {
    		String name = (String)e.nextElement();
    		String value = props.getProperty(name);
    		if (name.startsWith("json_${env.Environment}")) 
    		{
			        println name
					println value
					println "${env.Environment}"
					splitarray = name.split("json_${env.Environment}_")
					jsonvalue = splitarray[1]
					println jsonvalue
					key = "${jsonvalue}"
					transformvalue = "${value}"
					def someString = "${key}"
					
				def someChar = '.'
				int count = 0;
				for (int i = 0; i < someString.length(); i++) 
				{
				if (someString.charAt(i) == someChar) 
				{
					count++; 
				}
				}
				println count
				def slurper = new groovy.json.JsonSlurper()
				File jsonfile = new File(jsonfilepath)
				def json = slurper.parse(jsonfile)
				keyvalue = "json"
				println key
				splitarray = key.split('\\.')
				for(int j=0; j<=count ;j++)
				{
						
					keyvalue = keyvalue+"."+splitarray[j]
					
					if(j==count)
					{
						println keyvalue
						Eval.me('json',json,"$keyvalue ='$transformvalue'")
					}
				}
				def builder = new JsonBuilder(json)
				File outputFile = new File(jsonfilepath)
				outputFile.write(builder.toPrettyString())
       }
        		
    }
}

return this;