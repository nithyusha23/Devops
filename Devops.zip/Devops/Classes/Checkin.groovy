def commitLogs(def workspace,def gitcheckoutcredentials,def gitcheckincredentials)
{
	try
	{
		dir("${workspace}\\Devops")
		{
			common = load "$workspace\\Devops\\Classes\\Commonmethods.groovy"
			common.filecopyoperation("DeploymentLogs\\${env.Environment}\\Deploymentdetails.properties", ".")
			common.folderdeleteoperation("DeploymentLogs")
			checkout = load "${workspace}\\Devops\\Classes\\Checkout.groovy"
			checkout.checkout("${env.devopsbranch}","${gitcheckoutcredentials}","${env.devopsurl}")
		    //sshagent(['b075b292-3f9f-4cf7-857b-5c186a1d5cbd'])
		    //withCredentials([usernamePassword(credentialsId: "${gitcheckincredentials}", passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')])
		    withCredentials([sshUserPrivateKey(credentialsId: 'b075b292-3f9f-4cf7-857b-5c186a1d5cbd', keyFileVariable: 'gitkeyfile', passphraseVariable: 'gitpassphrase', usernameVariable: 'GIT_USERNAME')])
			{
				bat """
					git config --local user.email Ranjit_karni@epam.com
					git config --local user.name "${GIT_USERNAME}"
					mkdir \"${workspace}\\Devops\\DeploymentLogs\\${env.Environment}\"
					git pull origin ${env.devopsbranch}
					copy /Y \"${workspace}\\Devops\\Deploymentdetails.properties\" \"${workspace}\\Devops\\DeploymentLogs\\${env.Environment}\\Deploymentdetails.properties\"
					git add \"DeploymentLogs\\${env.Environment}\\Deploymentdetails.properties\"
					git commit -m \"CI commit Deploymentdetails.Properties}\"
					git push origin ${env.devopsbranch}
				"""	
			}			
						
			
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to commit logs to gitlab--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;