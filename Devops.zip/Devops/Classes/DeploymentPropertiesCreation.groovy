String path
File file
def createDeploymentProperties(def workspace,def propertyfilepath)
{
	path="${workspace}\\Devops\\DeploymentLogs\\${env.Environment}"    
	file = new File(path)
	if (!file.exists()) 
	{
         file.mkdir()
    }
	props = new Properties()
	File check = new File("${workspace}\\${propertyfilepath}")
	if(check.exists())
	{
		 props.load(check.newDataInputStream())
		 props.setProperty('LatestShaCode',"${env.revisionID}")
		 props.setProperty('GitBranch',"${env.Branch}")
		 props.setProperty('Version',"${env.folderversion}")
		 props.setProperty('Service Name',"${env.JOB_NAME}")
		 props.store(check.newWriter(), null)
	}

	else
	{
		  OutputStream os 
		  props.setProperty('LatestShaCode',"${env.revisionID}")
		  props.setProperty('GitBranch',"${env.Branch}")
		  props.setProperty('Version',"${env.folderversion}")
		   props.setProperty('Service Name',"${env.JOB_NAME}")
		  os = new FileOutputStream("${workspace}\\${propertyfilepath}");
		  props.store(os,"Create Property File");
	}
	env.PreviousShaCode = props.getProperty('PreviousShaCode')
	env.LatestShaCode = props.getProperty('LatestShaCode')
}
return this;