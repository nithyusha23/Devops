def copy
def createArtifactFolder(def workspace)
{
	try
	{
		bat """mkdir \"${workspace}\\Artifacts\\${env.Environment}\\${env.Git_Tag.replace(" ","")}\\Deployment\" ;\"${workspace}\\Artifacts\\${env.Environment}\\${env.Git_Tag.replace(" ","")}\\Logs\"; """
		if(env.dbdeployment=='true')
		{
		    bat """ \"${workspace}\\Artifacts\\${env.Environment}\\${env.Git_Tag.replace(" ","")}\\DB\" """
		}    
	}
	catch(Exception e)
	{
		echo "-------Failed to set the folder version--------------"
		error e.message
	}
	finally
	{
	
	}
}

def copyFilesToArtifacts(def workspace)
{
	try
	{
		copy = load "$workspace\\Devops\\Classes\\Commonmethods.groovy"
		dir("${workspace}")
		{
			copy.foldercopyoperation("${env.publishfolder}","Artifacts\\${env.Environment}\\${env.Git_Tag.replace(" ","")}\\Deployment")
			copy.filecopyoperation("${env.deploymentdetailslocation}\\${env.Environment}\\Deploymentdetails.properties","Artifacts\\${env.Environment}\\${env.Git_Tag.replace(" ","")}\\Logs")
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to copy the required files to artifacts folder--------------"
		error e.message
	}
	finally
	{
	
	}
}

def zipArtifacts(def workspace)
{
	dir("$workspace\\Artifacts\\${env.Environment}")
	{
		try
		{
			copy.filezipoperation("${env.Git_Tag.replace(" ","")}")
		}
		catch(Exception e)
		{
			echo "-------Failed to zip the artifacts--------------"
			error e.message
		}
		finally
		{
		
		}
	}
	
}
return this;