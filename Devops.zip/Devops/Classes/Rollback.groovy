def performRollback(def workspace,def jfrogcredentials,def servercredentials)
{
	if("${env.RollbackVersion}"=="")
	{
		echo "Version to be rolled back is mandatory"
		error "Version to be rolled back is mandatory"
	}
	else
	{
		try
		{
			env.JfrogRepoUrl = "${env.artifactoryurl}/${env.jfrogrepo}/${env.RollbackVersion}"
			withCredentials([usernamePassword(credentialsId: "${jfrogcredentials}", passwordVariable: 'Jfrogpassword', usernameVariable: 'Jfroguser')]) 
			{
				bat """curl -u %Jfroguser%:%Jfrogpassword% -k \"${JfrogRepoUrl}\" -o \"${workspace}\\${env.RollbackVersion}\""""
			}
			copy = load "$workspace\\Devops\\Classes\\Commonmethods.groovy"
			copy.fileunzipoperation("${workspace}\\${env.RollbackVersion}","${workspace}")
			splitarray = "${env.RollbackVersion}".split(".zip")
			rollbackfolder = splitarray[0]
			withCredentials([string(credentialsId: "${servercredentials}", variable: 'ServerPassword')])
			{
				bat """
					NET USE \\\\${env.servername}\\IPC"\$" /USER:${env.serverusername} ${ServerPassword}
					rd /s /q \\\\${env.servername}\\D"\$"\\${env.deploymentlocation}
					robocopy ${rollbackfolder}\\Deployment\\web \\\\${env.servername}\\D"\$"\\${env.deploymentlocation} /s
					Net use * /delete /y
				"""
			}	
		}
		catch(Exception e)
		{
			echo "-------Failed to perform Rollback--------------"
			error e.message
		}
		finally
		{
			
		}
	}
}
return this;