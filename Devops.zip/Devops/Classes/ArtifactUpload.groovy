def artifactUploadS3(def workspace)
{
	try
	{
		s3Upload consoleLogLevel: 'INFO',
		dontWaitForConcurrentBuildCompletion: false, 
		entries: [
			[bucket: "devops-dlyrepo/MIOnline/MicroServices",
			excludedFile: '', 
			flatten: false, 
			gzipFiles: false, 
			keepForever: false, 
			managedArtifacts: false, 
			noUploadOnFailure: true, 
			selectedRegion: 'us-gov-west-1', 
			showDirectlyInBrowser: false, 
			sourceFile: "Artifacts\\\\${env.Environment}\\\\${env.Git_Tag.replace(" ","")}.zip", 
			storageClass: 'STANDARD', 
			uploadFromSlave: true, 
			useServerSideEncryption: false]
		], 
		pluginFailureResultConstraint: 'FAILURE', 
		profileName: 'devops-dlyrepo', 
		userMetadata: []
	}
	catch(Exception e)
	{
		echo "-------Failed to upload artifacts to S3--------------"
		error e.message
	}
	finally
	{
		
	}
}
def artifactuploadJFrog(def workspace,def jfrogcredentials)
{
	try
	{
		env.JfrogRepoUrl = "${env.artifactoryurl}/${env.Job_Name}_${env.Environment}/${env.	Git_Tag}.zip"
		withCredentials([usernamePassword(credentialsId: "${jfrogcredentials}", passwordVariable: 'Jfrogpassword', usernameVariable: 'Jfroguser')]) 
		{
			bat """curl -v -u %Jfroguser%:%Jfrogpassword% -k -X PUT \"${JfrogRepoUrl}\" -T \"${workspace}\\Artifacts\\${env.Environment}\\${env.Git_Tag.replace(" ","")}.zip\""""
		}
		
	}
	catch(Exception e)
	{
		echo "-------Failed to upload artifacts to JFrog--------------"
		error e.message
	}
	finally
	{
		
	}
}
return this;