def sonarAngularJS(def workspace)
{
	try
	{
		withEnv(["PATH+JDK=$env.javaHome/bin"])
		{
			dir("${workspace}\\${env.npmdirectory}")
			{
			    bat "npm cache clean --f"
				bat "npm install -g karma-cli"
				bat "npm install git+https://github.com/karma-runner/karma-cli.git"
				nodeModulesPath = "${workspace}\\${env.npmdirectory}\\node_modules\\.bin"
				withEnv(["PATH+WHATEVER=$nodeModulesPath"]) 
				{
					bat "karma start karma.conf.js --sinlge-run=true"
				}
			}
			propfile = load "$workspace\\Devops\\Classes\\SonarAngularJS.groovy"
			propfile.createpropertyfile(workspace)
			withSonarQubeEnv('SonarQube')
			{
				bat "\"${env.SonarQube}\\bin\\sonar-scanner.bat\""
			}
			sleep(30)
			timeout(time:1, unit: 'MINUTES') 
			{ 
				def qg = waitForQualityGate() 
				if ((qg.status != 'OK')) 
				{
					echo "----------------AngularJS Quality Gate Failure-------------------------"
					error "Pipeline aborted due to following quality gate failure: StaticScan=${qg.status}"
				}              
									
			}
			delete = load "$workspace\\Devops\\Classes\\Commonmethods.groovy"
			delete.filedeleteoperation("sonar-project.properties")

		}
		
	}
	catch(Exception e)
	{
		echo "-------Failed to perform sonar analysis on AngularJS Code--------------"
		error e.message
	}
	finally
	{
	
	}
}

def createpropertyfile(String path)
{
	props = new Properties()
	OutputStream os
	props.setProperty('sonar.projectKey','MIOnlineWeb_JS')
	props.setProperty('sonar.projectName','MIOnlineWeb_JS')
	props.setProperty('sonar.projectVersion','1.0')
	props.setProperty('sonar.login','admin')
	props.setProperty('sonar.password','admin')
	props.setProperty('sonar.language','js')
	props.setProperty('sonar.sources','./Radian Web Applications/MI Online/MIOnline.WebUI')
	props.setProperty('sonar.javascript.lcov.reportPaths','./Radian Web Applications/MI Online/MIOnline.WebUI/coverage/report-lcov/lcov.info')
	props.setProperty('sonar.sourceEncoding','UTF-8')
	props.setProperty('sonar.exclusions','**/Scripts/*.js,**/*.spec.js,**/*.html,/**/**/*.spec.js,**/node_modules/**,**/coverage/**/*.js,**/gulp_plugins/**,**/gulpfile.js,**/karma.conf.js,**/bin/*.js,**/only-digits.js,**/only-floats.js')
	os = new FileOutputStream("${path}\\sonar-project.properties")
	props.store(os,"Create Property File")
}
return this;