def dbDeployment(def workspace)
{
	try
	{
		msdbcmd = "\"${env.msbuildpath}\" \"${env.dbprojectpath}\" /t:rebuild;publish /p:Configuration=Debug /p:VisualStudioVersion=14.0 /p:SQLPublishProfilePath=\"${workspace}\\${env.dbtransformationoutputfilepath}\""
		bat msdbcmd
		dir("${workspace}")
		{
    		copy.filecopyoperation("${env.dacpacfilelocation}\\MIOnlineDB.dacpac","Artifacts\\${env.Environment}\\${env.folderversion}\\DB")
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to perform DB Deployment--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;