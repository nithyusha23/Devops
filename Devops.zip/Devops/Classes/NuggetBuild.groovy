def buildNugget(def workspace)
{
	try
	{
		env.msBuildNuGetCmd = "\"${workspace}\\$env.msbuildnuggetpath\" restore \"${workspace}\\$env.slnpath"
		bat msBuildNuGetCmd
	}
	catch(Exception e)
	{
		echo "-------Failed to install the Nugget package--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;