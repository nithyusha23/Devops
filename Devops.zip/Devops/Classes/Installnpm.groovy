def npmInstall(def workspace)
{
	try
	{
		dir("${workspace}\\$env.npmdirectory") 
		{
		    /*try
		    {
		        bat "\"$env.npmpath\" cache clean --force"
		        bat "\"$env.npmpath\" cache verify"
		    }
		    catch(Exception e)
			{
			    error e.message
			}*/
			bat "\"$env.npmpath\" install -force"
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to install npm modules--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;