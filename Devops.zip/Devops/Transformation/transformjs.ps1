param(
    [Parameter(Mandatory=$true)]
    [string]$scriptpath,
    
    [Parameter(Mandatory=$true)]
    [string]$PolicyInquiryUrl,

    [Parameter(Mandatory=$true)]
    [string]$Username,

    [Parameter(Mandatory=$true)]
    [string]$Password,

    [Parameter(Mandatory=$true)]
    [string]$Environment

)
$APPConfig = $scriptpath 
$doc = Get-Content $APPConfig -Raw | ConvertFrom-Json

$doc.ServiceURLs.PolicyInquiryURL = $PolicyInquiryUrl
$doc.Credentials.bizTalkUserName = $Username
$doc.Credentials.bizTalkPassword = $Password
$doc.Environment = $Environment

$doc | ConvertTo-Json  | set-content $APPConfig