param(
    [Parameter(Mandatory=$true)]
    [string]$scriptpath,
    
    [Parameter(Mandatory=$true)]
    [string]$PAS,

    [Parameter(Mandatory=$true)]
    [string]$SOLR,

    [Parameter(Mandatory=$true)]
    [string]$SFDC,

    [Parameter(Mandatory=$true)]
    [string]$GetOCARUrl,
    
[Parameter(Mandatory=$true)]
    [string]$VMS,

    [Parameter(Mandatory=$true)]
    [string]$GetOCAR_VMSUrl,
)
$APPConfig = $scriptpath 
$doc = Get-Content $APPConfig -Raw | ConvertFrom-Json

$doc.ServiceURLs.PAS = $PAS
$doc.ServiceURLs.SOLR = $SOLR
$doc.ServiceURLs.SFDC = $SFDC
$doc.ServiceURLs.GetOCARUrl = $GetOCARUrlt
$doc.ServiceURLs.VMS = $VMS
$doc.ServiceURLs.GetOCAR_VMSUrl = $GetOCAR_VMSUrl

$doc | ConvertTo-Json  | set-content $APPConfig
