param(
    [Parameter(Mandatory=$true)]
    [string]$version,
	[Parameter(Mandatory=$true)]
    [string]$workspacepath,
    [Parameter(Mandatory=$true)]
    [string]$buildfolderpath
)

$ErrorActionPreference="Stop"

$source = "$workspacepath\$buildfolderpath"

$destination = "$workspacepath\$version.zip"

 If(Test-path $destination) {Remove-item $destination}

Add-Type -assembly "system.io.compression.filesystem"

[io.compression.zipfile]::CreateFromDirectory($source, $destination)