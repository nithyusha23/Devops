def sonarAnalysis(def workspace)
{
	try
	{
		bat """ copy /y \"${workspace}\\${env.Foldername}\\${env.Devops}\\${env.Foldername}\\sonar-project.properties\" \"${workspace}\\${env.Foldername}\" """
		withSonarQubeEnv('SonarQube') 
		{
			withEnv(["workspace=${workspace}\\${env.Foldername}"]) 
			{
				bat """ \"${env.SonarQube}\\bin\\sonar-scanner.bat\"  """
			}
			
		}
		sleep(10)
		timeout(time:2, unit: 'MINUTES') 
		{ 
			def qg = waitForQualityGate() 
			if ((qg.status == 'ERROR')) 
			{
				error "Pipeline aborted due to following quality gate failure: StaticScan=${qg.status}"
			}              
								
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to perform sonar analysis --------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;