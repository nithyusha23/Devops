def uploadArtifacts(def workspace,def gitcredentials)
{
	try
	{
		bat """ Powershell.exe -executionpolicy remotesigned -File \"${workspace}\\${env.Foldername}\\${env.Devops}\\ZipArtifacts.ps1\" -version ${env.versionnumber} -workspacepath ${workspace}\\${env.Foldername} -buildfolderpath ${env.buildfolder} """
		bat """ dir \"${workspace}\\${env.Foldername}\" """
		withCredentials([usernamePassword(credentialsId: "${gitcredentials}", passwordVariable: 'artifactpassword', usernameVariable: 'artifactusername')])
		{
			rtUpload (
				serverId: "TR-Artifactory",
				spec:
					"""{
					  "files": [
						{
						  "pattern": "${workspace}\\${env.Foldername}\\*.zip",
						  "target": "${env.jfrogrepopath}"
						}
					 ]
					}"""
			)
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to upload the artifacts to BAMS--------------"
		error e.message
	}
	finally
	{
	
	}
		
}
return this;