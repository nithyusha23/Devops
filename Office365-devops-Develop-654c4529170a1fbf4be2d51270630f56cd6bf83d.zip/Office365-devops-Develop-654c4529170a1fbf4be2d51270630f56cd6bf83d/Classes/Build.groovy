def transformpackagejson(def appjsonpath,String versionnumber)
{
	json = readJSON file: appjsonpath
	json.version = versionnumber
	println "package.json after transformation: ${json}"
	writeJSON file:appjsonpath, json:json
}
def performBuild(def workspace)
{
	try
	{
		echo "Performing build"
		transformpackagejson("${workspace}\\${env.Foldername}\\package.json","${env.versionnumber}")
		bat """ npm install """
		bat """ npm install -g @elf/cli """
		bat """ npm dedupe """
		bat """npm run build:prod"""
	}	
	catch(Exception e)
	{
		echo "-------Failed to perform the build--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;	
