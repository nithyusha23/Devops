def emailnotification(String version, String buildstatus,String AlphaDeployment, String BetaDeployment, String ProdDeployment) {
	emailext (
	subject: "Jenkins job Name:: ${env.JOB_NAME} - Version: ${version} - Build Status: "+currentBuild.currentResult,
body: 
"""
PROJECT :${env.JOB_NAME}
BUILD NUMBER :${env.BUILD_NUMBER}
Version :${version}
Deployment to Alpha : ${AlphaDeployment}
Deployment to Beta : ${BetaDeployment}
Deployment to Prod : ${ProdDeployment}
Build Status :${currentBuild.currentResult}
Check console output at : ${env.BUILD_URL}console
""",
	to: "${env.Email_Recipients}",
	attachLog: true
	 )
 }
def failureemailnotification(String version, String buildstatus,String errormsg, String AlphaDeployment, String BetaDeployment, String ProdDeployment) {
	emailext (
	subject: "Jenkins job Name:: ${env.JOB_NAME} - Version: ${version} - Build Status: "+currentBuild.currentResult,
body: 
"""
PROJECT :${env.JOB_NAME}
BUILD NUMBER :${env.BUILD_NUMBER}
Version :${version}
Deployment to Alpha : ${AlphaDeployment}
Deployment to Beta : ${BetaDeployment}
Deployment to Prod : ${ProdDeployment}
Error :${errormsg}
Check console output at : ${env.BUILD_URL}console
""",
	to: "${env.Email_Recipients}",
	attachLog: true
	 )
 } 
return this; 