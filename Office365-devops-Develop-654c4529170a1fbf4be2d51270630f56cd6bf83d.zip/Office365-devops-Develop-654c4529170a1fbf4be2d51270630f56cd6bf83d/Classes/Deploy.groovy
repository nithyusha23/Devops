def transformappjson(def appjsonpath,String versionnumber)
{
	json = readJSON file: appjsonpath
	json.version = versionnumber.toString()
	println "app.json after transformation: ${json}"
	writeJSON file:appjsonpath, json:json
}

def deployAlpha(def workspace)
{
	transformappjson("${workspace}\\${env.Foldername}\\${env.buildfolder}\\app.json","${env.versionnumber}")
	echo "Deploying the code to Alpha"
	deployment = bat(returnStdout: true, script: """ \"${workspace}\\${env.Foldername}\\${env.Devops}\\Publisher\\eem_deploy.exe\" Alpha apppackage \"${workspace}\\${env.Foldername}\\${env.buildfolder}\" -N ${env.deploymentfoldername} """).trim()	
	echo "Deployment log is ${deployment}"
	if("${deployment}".contains('Upload succeeded'))
	{
		echo "Deployment to Alpha Succeeded"
	}
	else
	{
		error "Deployment to Alpha failed"
	}
}
def deployHigherEnvironment(def workspace, def datacenters, def environment)
{
	if("${env.Alpha}"=="true")
	{
		deployment = bat(returnStdout: true, script: """ \"${workspace}\\${env.Foldername}\\${env.Devops}\\Publisher\\eem_deploy.exe\" \"${datacenters}\" apppackage \"${workspace}\\${env.Foldername}\\${env.buildfolder}\" -N ${env.deploymentfoldername} """).trim()
		echo "Deployment log is ${deployment}"
		if("${deployment}".contains('Upload succeeded'))
		{
			echo "Deployment to ${environment} Succeeded"
		}
		else
		{
			error "Deployment to ${environment} failed"
		}
	}
	else
	{
		if("${env.Version}"=="")
		{
			error "Version Number is mandatory to download artifacts and deploy to Beta"
			
		}
		else
		{
			
				versiondownload = "${env.jfrogrepopath}"+"${env.Version}"
				 rtDownload(
					serverId: "TR-Artifactory",
					spec:
						"""{
						  "files": [
							{
							  "pattern": "${versiondownload}",
							  "target": "${workspace}\\${env.Foldername}\\${env.Version}"
							}
						 ]
						}"""
				)
				bat """ dir /b /a-d \"${workspace}\\${env.Foldername}" """
				splitarray = "${env.Version}".split(".zip")
				artifactsfolder = splitarray[0]
				bat """ Powershell.exe -executionpolicy remotesigned -File \"${workspace}\\${env.Foldername}\\${env.Devops}\\UnzipArtifacts.ps1\" -zipfile ${workspace}\\${env.Foldername}\\${env.Foldername}\\${env.Version} -outputpath ${workspace}\\${env.Foldername}\\${artifactsfolder} """
				deployment = bat(returnStdout: true, script: """ \"${workspace}\\${env.Foldername}\\${env.Devops}\\Publisher\\eem_deploy.exe\" \"${datacenters}\" apppackage \"${workspace}\\${env.Foldername}\\${artifactsfolder}\" -N ${env.deploymentfoldername} """).trim()
				echo "Deployment log is ${deployment}"
				if("${deployment}".contains('Upload succeeded'))
				{
					echo "Deployment to ${environment} Succeeded"
				}
				else
				{
					error "Deployment to ${environment} failed"
				}
				
				

		}	
	}
}
return this;