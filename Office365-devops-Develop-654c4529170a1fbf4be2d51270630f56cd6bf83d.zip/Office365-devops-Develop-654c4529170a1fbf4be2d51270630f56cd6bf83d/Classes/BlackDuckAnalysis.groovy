def blackduckAnalysis(def workspace, def blackduckcredentials)
{
	try
	{
		withCredentials([usernamePassword(credentialsId: "${blackduckcredentials}", passwordVariable: 'blackduckpassword', usernameVariable: 'blackduckusername')]) 
		{
			withEnv([ "blackduckprojectname=${env.blackduckprojectname}",
								"workspace=${workspace}\\${env.Foldername}","buildfolder=${env.buildfolder}","blackduckurl=${env.blackduckurl}"
			]) {					
			synopsys_detect ("--detect.source.path='${workspace}\\${Foldername}\\${buildfolder}' --detect.project.name='${blackduckprojectname}' --detect.project.version.name='Daily' --blackduck.url='${blackduckurl}' --blackduck.username='${blackduckusername}' --blackduck.password='${blackduckpassword}'")
			}
			
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to perform BlackDuck analysis --------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;