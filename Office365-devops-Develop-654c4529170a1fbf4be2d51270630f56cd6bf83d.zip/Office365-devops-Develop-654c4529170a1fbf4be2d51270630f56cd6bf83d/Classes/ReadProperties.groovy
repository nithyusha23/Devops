def callreadProperties(def workspace,def path)
{
	try
	{
		Properties props = new Properties()
		String propfile = readFile(path)
		StringReader reader = new StringReader(propfile); 
		props.load(reader)
		env.buildfolder = props.getProperty('buildfolder')
		echo "Build Folder is : ${env.buildfolder}"
		env.blackduckurl = props.getProperty('blackduckurl')
		env.blackduckprojectname = props.getProperty('blackduckprojectname')
		env.proxyurl = props.getProperty('proxyurl')
		env.majorversion = props.getProperty('majorversion')
		env.minorversion = props.getProperty('minorversion')
		env.jfrogrepopath = props.getProperty('jfrogrepopath')
		env.artifactoryurl = props.getProperty('artifactoryurl')
		env.deploymentfoldername = props.getProperty('deploymentfoldername')
		env.bamsregistryurl = props.getProperty('bamsregistryurl')
		env.globalregistry = props.getProperty('globalregistry')
		env.tremail = props.getProperty('tremail')
		
		
	}
	catch(Exception e)
	{
		echo "-------Failed to read the Properties file--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;