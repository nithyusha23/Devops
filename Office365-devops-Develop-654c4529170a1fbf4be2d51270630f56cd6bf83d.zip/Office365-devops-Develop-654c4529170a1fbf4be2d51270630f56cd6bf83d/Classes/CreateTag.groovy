def createTag(def workspace,def gitcredentials)
{
	try
	{
		withCredentials([usernamePassword(credentialsId: "${gitcredentials}", passwordVariable: 'gitpassword', usernameVariable: 'gitusername')])
		{
			tagversion = "O365-CI-"+"${versionnumber}"
			bat """ git tag ${tagversion} """
			bat """ git push https://${gitusername}:${gitpassword}@git.sami.int.thomsonreuters.com/EikonOffice/O365-Online.git --tags """
		}
	}
	catch(Exception e)
	{
		echo "-------Failed to create tag in git --------------"
		error e.message
	}
	finally
	{
	
	}
}
return this; 