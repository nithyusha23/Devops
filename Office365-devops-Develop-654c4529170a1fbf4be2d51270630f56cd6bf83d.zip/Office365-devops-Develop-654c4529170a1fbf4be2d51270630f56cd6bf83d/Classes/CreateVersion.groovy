def createVersion()
{
	try
	{
		env.versionnumber = "${env.majorversion}"+ '.'+"${env.minorversion}"+"."+"${env.BUILD_NUMBER}"
		echo "Versionnumber is ${versionnumber}"
	}	
	catch(Exception e)
	{
		echo "-------Failed to create the version--------------"
		error e.message
	}
	finally
	{
	
	}
}
return this;
