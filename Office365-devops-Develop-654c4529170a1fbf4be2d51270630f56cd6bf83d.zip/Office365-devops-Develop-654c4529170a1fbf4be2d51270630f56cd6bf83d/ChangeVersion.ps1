param(
    [Parameter(Mandatory=$true)]
    [string]$propertiesfile,
	
	[Parameter(Mandatory=$true)]
    [string]$previousalphaversion,
	
	[Parameter(Mandatory=$true)]
    [string]$newalphaversion
)	
$oldalphaversion = 'Alpha='+$previousalphaversion
$newalphaversion = 'Alpha='+$newalphaversion
(Get-Content $propertiesfile).replace($oldalphaversion,$newalphaversion) | Set-Content $propertiesfile
